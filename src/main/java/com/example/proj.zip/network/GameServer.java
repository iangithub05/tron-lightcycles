package com.example.network;

import com.example.models.Direction;
import com.example.models.Game;
import com.example.models.LobbySettings;
import com.example.models.Player;
import com.example.models.Point;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;

public class GameServer {
    public Consumer<Integer> onPlayerCountChanged;
    public BiConsumer<String,String> onChatMessage;
    public Consumer<String> onPlayerDisconnected;
    public Consumer<String> onError;
    public BiConsumer<Integer,int[]> onRoundOver;
    public Consumer<Integer> onMatchOver;
    private LobbySettings settings;
    private Game           game;
    private int[]          matchScores;

    private ServerSocket           serverSocket;
    private final List<ClientConn> clients    = new CopyOnWriteArrayList<>();
    private final List<String>     playerNames = new CopyOnWriteArrayList<>();

    private LanDiscovery discovery;
    private String       roomCode;
    private String       hostName;

    private Timer        gameTimer;
    private boolean      gameRunning;

    private class ClientConn {
        final int    slot;
        final Socket socket;
        final BufferedReader  in;
        final PrintWriter     out;
        Direction pendingDir;

        ClientConn(int slot, Socket socket) throws IOException {
            this.slot   = slot;
            this.socket = socket;
            this.in     = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.out    = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
        }

        void send(String msg) {
            out.println(msg);
        }
    }


    public void listen(int port, LobbySettings settings, String hostName) {
        this.settings  = settings;
        this.hostName  = hostName;
        this.matchScores = new int[settings.maxPlayers];

        playerNames.add(hostName);

        roomCode  = RoomCode.encode(RoomCode.getLocalIp(), port);
        discovery = new LanDiscovery();
        discovery.startResponder(roomCode, hostName, 1, settings.maxPlayers);

        Thread acceptThread = new Thread(() -> {
            try {
                serverSocket = new ServerSocket(port);
                while (!serverSocket.isClosed()) {
                    Socket s = serverSocket.accept();
                    int slot = clients.size() + 1;
                    if (slot >= settings.maxPlayers) {
                        s.close();
                        continue;
                    }
                    ClientConn conn = new ClientConn(slot, s);
                    clients.add(conn);
                    startClientReader(conn);
                }
            } catch (IOException e) {
                if (!serverSocket.isClosed())
                    if (onError != null) onError.accept(e.getMessage());
            }
        }, "server-accept");
        acceptThread.setDaemon(true);
        acceptThread.start();
    }

    public String getRoomCode() { return roomCode; }
    public String getLocalIp() { return RoomCode.getLocalIp(); }

    public void updateSettings(LobbySettings s) {
        this.settings = s;
        broadcast(NetworkMessage.make(NetworkMessage.SETTINGS, s.encode()));
        if (discovery != null)
            discovery.updatePlayerCount(roomCode, hostName,
                                        clients.size() + 1, s.maxPlayers);
    }

    public void sendChat(String name, String message) {
        broadcast(NetworkMessage.make(NetworkMessage.CHAT, name, message));
        if (onChatMessage != null) onChatMessage.accept(name, message);
    }

    public void startGame() {
        buildGame();
        broadcast(NetworkMessage.make(NetworkMessage.START));
        discovery.stopResponder();
        beginGameLoop();
    }

    public void queueHostDirection(Direction dir) {
        hostDir = dir;
    }

    private volatile Direction hostDir = null;

    public void close() {
        gameRunning = false;
        if (gameTimer  != null) gameTimer.cancel();
        if (discovery  != null) discovery.stopResponder();
        for (ClientConn c : clients) closeConn(c);
        try { if (serverSocket != null) serverSocket.close(); } catch (IOException ignored) {}
    }

    public Game       getGame() { return game; }
    public LobbySettings getSettings() { return settings; }
    public List<String> getPlayerNames() { return new java.util.ArrayList<>(playerNames); }


    private void startClientReader(ClientConn conn) {
        Thread t = new Thread(() -> {
            try {
                String line;
                while ((line = conn.in.readLine()) != null) {
                    handleClientMessage(conn, line.trim());
                }
            } catch (IOException ignored) {
            } finally {
                handleClientDisconnect(conn);
            }
        }, "server-client-" + conn.slot);
        t.setDaemon(true);
        t.start();
    }

    private void handleClientMessage(ClientConn conn, String raw) {
        String[] parts = NetworkMessage.parse(raw);
        switch (parts[0]) {
            case NetworkMessage.HELLO -> {
                String name = parts.length > 1 ? parts[1] : "PLAYER";
                while (playerNames.size() <= conn.slot) playerNames.add("");
                playerNames.set(conn.slot, name);
                conn.send(NetworkMessage.make(NetworkMessage.WELCOME,
                        String.valueOf(conn.slot), settings.encode()));
                broadcastLobbyState();
                if (onPlayerCountChanged != null)
                    onPlayerCountChanged.accept(clients.size() + 1);
                if (discovery != null)
                    discovery.updatePlayerCount(roomCode, hostName,
                                                clients.size() + 1, settings.maxPlayers);
            }
            case NetworkMessage.INPUT -> {
                if (parts.length > 1) {
                    try {
                        conn.pendingDir = Direction.valueOf(parts[1]);
                    } catch (Exception ignored) {}
                }
            }
            case NetworkMessage.CHAT -> {
                if (parts.length > 2) {
                    broadcast(raw);
                    if (onChatMessage != null) onChatMessage.accept(parts[1], parts[2]);
                }
            }
            case NetworkMessage.PING -> conn.send(NetworkMessage.PONG);
        }
    }

    private void handleClientDisconnect(ClientConn conn) {
        String name = conn.slot < playerNames.size()
                ? playerNames.get(conn.slot) : "PLAYER";
        clients.remove(conn);
        closeConn(conn);
        broadcast(NetworkMessage.make(NetworkMessage.DISCONNECT, name));
        if (onPlayerDisconnected != null) onPlayerDisconnected.accept(name);
        broadcastLobbyState();
        if (onPlayerCountChanged != null)
            onPlayerCountChanged.accept(clients.size() + 1);
    }

    private void buildGame() {
        game = new Game(settings.toGameRules());
        double[][] startPos = {
 {80, 80}, {settings.gridWidth - 80, 80},
 {settings.gridWidth - 80, settings.gridHeight - 80}, {80, settings.gridHeight - 80}
        };
        com.example.models.Direction[] startDir = {
            Direction.RIGHT, Direction.DOWN, Direction.LEFT, Direction.UP
        };
        int total = clients.size() + 1;
        for (int i = 0; i < total; i++) {
            game.addPlayer(new Player(startPos[i][0], startPos[i][1],
                                      startDir[i], settings.toGameRules().playerSpeed));
        }
    }

    private void beginGameLoop() {
        gameRunning = true;
        long tickMs  = 16;
        gameTimer = new Timer("game-loop", true);
        gameTimer.scheduleAtFixedRate(new TimerTask() {
            @Override public void run() {
                if (!gameRunning) { cancel(); return; }
                readInputs();
                game.update();
                broadcastState();
                if (game.isOver()) {
                    gameRunning = false;
                    cancel();
                    Player winner = game.getWinner();
                    int winSlot = winner != null ? game.players.indexOf(winner) : -1;
                    if (winSlot >= 0) matchScores[winSlot]++;
                    broadcast(NetworkMessage.make(NetworkMessage.ROUND_OVER,
                            String.valueOf(winSlot), scoresString()));
                    if (onRoundOver != null) onRoundOver.accept(winSlot, matchScores.clone());

                    if (winSlot >= 0 && matchScores[winSlot] >= settings.gamesToWin) {
                        broadcast(NetworkMessage.make(NetworkMessage.MATCH_OVER,
                                String.valueOf(winSlot)));
                        if (onMatchOver != null) onMatchOver.accept(winSlot);
                    }
                }
            }
        }, 0, tickMs);
    }

    private void readInputs() {
        if (hostDir != null && !game.players.isEmpty()) {
            game.players.get(0).setDirection(hostDir);
            hostDir = null;
        }
        for (ClientConn c : clients) {
            if (c.pendingDir != null && c.slot < game.players.size()) {
                game.players.get(c.slot).setDirection(c.pendingDir);
                c.pendingDir = null;
            }
        }
    }

    private void broadcastState() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < game.players.size(); i++) {
            if (i > 0) sb.append(';');
            Player p = game.players.get(i);
            var snap = new NetworkMessage.PlayerSnapshot();
            snap.slot = i;
            snap.x = p.x; snap.y = p.y; snap.alive = p.alive;
            snap.trailPoints = new ArrayList<>();
            for (Point pt : p.trail.points)
                snap.trailPoints.add(new double[]{pt.x, pt.y});
            sb.append(snap.encode());
        }
        broadcast(NetworkMessage.make(NetworkMessage.STATE, sb.toString()));
    }

    private void broadcastLobbyState() {
        broadcast(NetworkMessage.make(NetworkMessage.LOBBY_STATE,
                String.join(",", playerNames)));
    }

    private void broadcast(String msg) {
        for (ClientConn c : clients) c.send(msg);
    }

    private String scoresString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < matchScores.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(matchScores[i]);
        }
        return sb.toString();
    }

    private void closeConn(ClientConn c) {
        try { c.socket.close(); } catch (IOException ignored) {}
    }
}